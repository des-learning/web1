registerPlugin({
    eval: function() {
        throw new Error("An error was here.")
    }
});